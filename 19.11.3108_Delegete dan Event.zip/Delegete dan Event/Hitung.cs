﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Calculator_2
{
    public class Hitung
    {
        public string operasi { get; set; }
        public string a { get; set; }
        public string b { get; set; }
        public string Hasil { get; set; }
    }
}
